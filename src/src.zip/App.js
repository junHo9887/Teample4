import React from 'react';
import Sub1 from './component/Sub1';
import SubHeader from './component/SubHeader';
import { BrowserRouter } from 'react-router-dom';

function App() {
    return (
        <BrowserRouter>
            <>
                <SubHeader />
                <Sub1 />
            </>
        </BrowserRouter>
    );
}

export default App;
